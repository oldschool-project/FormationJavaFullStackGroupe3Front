import { Component } from '@angular/core';

@Component({
  selector: 'app-page-reset',
  templateUrl: './page-reset.component.html',
  styleUrls: ['./page-reset.component.scss']
})
export class PageResetComponent {

}
