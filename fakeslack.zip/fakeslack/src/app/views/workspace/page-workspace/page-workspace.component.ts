import { Component } from '@angular/core';

@Component({
  selector: 'app-page-workspace',
  templateUrl: './page-workspace.component.html',
  styleUrls: ['./page-workspace.component.scss']
})
export class PageWorkspaceComponent {

}
