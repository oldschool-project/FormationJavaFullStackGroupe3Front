import { Component } from '@angular/core';

@Component({
  selector: 'app-page-edit-user',
  templateUrl: './page-edit-user.component.html',
  styleUrls: ['./page-edit-user.component.scss']
})
export class PageEditUserComponent {

}
