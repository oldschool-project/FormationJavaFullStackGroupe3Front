import { Component } from '@angular/core';

@Component({
  selector: 'app-page-delete-user',
  templateUrl: './page-delete-user.component.html',
  styleUrls: ['./page-delete-user.component.scss']
})
export class PageDeleteUserComponent {

}
