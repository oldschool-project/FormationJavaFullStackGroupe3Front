export interface IMessage {
  id: number;
  userId: number;
  chanelId: number;
  text: string;
  date: Date;
}
