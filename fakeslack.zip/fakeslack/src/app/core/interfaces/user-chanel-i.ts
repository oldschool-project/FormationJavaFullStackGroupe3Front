export interface IUserChannel {
  userId: number;
  chanelId: number;
}
