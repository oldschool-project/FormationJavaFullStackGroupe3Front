export interface IChanel {
  id: number;
  name: string;
}
